// (C) Copyright 2002-2007 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//

using System;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Windows;
using Autodesk.Windows;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

[assembly: CommandClass(typeof(CsMgdAcad8.adskCommands))]
namespace CsMgdAcad8
{
  /// <summary>
  /// Summary description for adskCommands.
  /// </summary>
  public partial class adskCommands
  {
    public adskCommands()
    {
    }

    static PaletteSet ps = null;
    public static UserControl1 wpfUserControl = null;
    // define the static window variables, these will stay valid for the
    // lifetime of the session
    // Define Command "AsdkCmd1"
    [CommandMethod("adskCmd1")]
    static public void Cmd1() // This method can have any name
    {
      // check to see if this command has not been run before
      if (ps == null)
      {
        // if not, then create our windows - first the paletteset container window
        // we won't generate a Guid for the paletteset as that would then require
        // demand loading
        ps = new PaletteSet("MyPalette");
        // next the WPF UserControl
        wpfUserControl = new UserControl1();        
        
        
        // now add the user control to the paletteset
        ps.AddVisual("WPF Palette", wpfUserControl);
      }

      // finally, we need to show the paletteset
      // this also serves as a way to redisplay the paletteset if closed
      // by the user
      ps.Visible = true;
    }
  }
}