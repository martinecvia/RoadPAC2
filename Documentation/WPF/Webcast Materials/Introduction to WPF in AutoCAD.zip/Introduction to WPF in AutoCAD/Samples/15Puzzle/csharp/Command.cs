using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows;
using Autodesk;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Windows;
using Autodesk.AutoCAD.PlottingServices;
using System.Collections.Generic;

[assembly: CommandClass(typeof(PuzzleProject.TestClass))]

namespace PuzzleProject
{
  public class TestClass
  {
    static Autodesk.AutoCAD.Windows.PaletteSet ps;
    static PuzzleProject.Puzzle wind;
    [CommandMethod("Test")]
    static public void Test()
    {
      if (ps == null)
      {
        ps = new Autodesk.AutoCAD.Windows.PaletteSet("Puzzle!", new Guid("F9153A70-EE5F-4703-8586-35780CBFBF3B"));
        ps.MinimumSize = new System.Drawing.Size(300, 300);
        ps.AddVisual("Puzzle!", wind = new PuzzleProject.Puzzle());
      }

      ps.Visible = true;
      ps.SizeChanged += new PaletteSetSizeEventHandler(ps_SizeChanged);
      wind.Width = ps.Size.Width;
      wind.Height = ps.Size.Height;
    }

    static void ps_SizeChanged(object sender, PaletteSetSizeEventArgs e)
    {
      wind.Width = e.Width;
      wind.Height = e.Height;
    }

  }
}


