using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PuzzleProject
{

    public partial class MyDocument : FlowDocumentPageViewer
    {
        public MyDocument()
        {
            InitializeComponent();
        }
    }
}