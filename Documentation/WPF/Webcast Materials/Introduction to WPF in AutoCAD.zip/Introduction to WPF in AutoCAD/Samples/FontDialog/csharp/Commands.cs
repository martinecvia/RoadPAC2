using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows;
using Autodesk;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Windows;
using Autodesk.AutoCAD.PlottingServices;
using System.Collections.Generic;

[assembly: CommandClass(typeof(FontDialogSample.TestClass))]

namespace FontDialogSample
{
  /// <summary>
  /// Summary description for Test. 
  /// </summary>
  /// 
  public class TestClass
  {
    [CommandMethod("Test")]
    static public void Test()
    {
      FontDialogSample.MainWindow wind = new FontDialogSample.MainWindow();
      wind.ShowDialog();
    }
  }
}


