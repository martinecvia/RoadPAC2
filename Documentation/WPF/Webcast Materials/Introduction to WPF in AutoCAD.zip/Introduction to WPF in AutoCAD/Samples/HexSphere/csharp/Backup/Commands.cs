using System;
using System.Collections;
using System.Runtime.InteropServices;
using System.Windows;
using Autodesk;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Windows;
using Autodesk.AutoCAD.PlottingServices;
using System.Collections.Generic;


[assembly: CommandClass(typeof(Ribbon.TestClass))]

namespace Ribbon
{
  /// <summary>
  /// Summary description for Test. 
  /// </summary>
  /// 
  public class TestClass
  {
    static Autodesk.AutoCAD.Windows.PaletteSet ps;
    static Ribbon.Window1 wind;
    [CommandMethod("Test")]
    static public void Test()
    {
      if (ps == null)
      {
        ps = new Autodesk.AutoCAD.Windows.PaletteSet("Sunny", new Guid("9E6AB0BF-87DE-4b62-8166-D9E84AE6FE22"));
        ps.MinimumSize = new System.Drawing.Size(300, 300);
        ps.AddVisual("Sunny", wind = new Ribbon.Window1());
      }

      ps.Visible = true;
      ps.SizeChanged += new PaletteSetSizeEventHandler(ps_SizeChanged);
      wind.Width = ps.Size.Width;
      wind.Height = ps.Size.Height;
    }

    static void ps_SizeChanged(object sender, PaletteSetSizeEventArgs e)
    {
      wind.Width = e.Width;
      wind.Height = e.Height;
    }

    [CommandMethod("In")]
    static public void Up()
    {
      wind._trackball.UpdateScale(10);
    }
    [CommandMethod("Out")]
    static public void Down()
    {
      
      wind._trackball.UpdateScale(-10);
    }
  }
}


