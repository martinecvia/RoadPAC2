namespace LogonScreen
{
    public partial class Resources_Toons
    {
        public Resources_Toons()
        {
            InitializeComponent();
        }
    }
}