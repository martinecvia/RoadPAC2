﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Autodesk.AutoCAD.Runtime;
namespace au2
{
    public class commands
    {
        [CommandMethod("modal")]
        public static void Modal()
        {
            using (Window1 dlg = new Window1())
            {
                bool ret = (bool)Autodesk.AutoCAD.ApplicationServices.Application.ShowModalWindow(dlg);
                if (ret)
                {
                    dlg.Commit();
                }
            }
        }

        [CommandMethod("modeless")]
        public static void Modeless()
        {
            Window2 dlg = new Window2();
            Autodesk.AutoCAD.ApplicationServices.Application.ShowModelessWindow(dlg);

        }
    }
}
